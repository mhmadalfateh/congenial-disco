# فاتح ماسنجر — Fateh Messenger

Android starter project with Arabic RTL dark navy/cyan UI and developer credit **محمد الفاتح**.

## Important status
This is a clean Android project scaffold and UI prototype. It is **not yet a real multi-user messaging service**. The current sample keeps demo messages in app memory. Add a trusted backend before using real accounts or messaging. Do not publish it as a functioning messenger until the backend and media features are implemented and tested on two devices.

## Build APK with GitHub Actions
1. Create a new GitHub repository.
2. Upload the *contents* of this folder (the `app`, `.github`, and Gradle files) to the repository root. Do not upload only the ZIP and expect Actions to build it.
3. Open **Actions** → **Build Fateh Messenger APK** → **Run workflow**.
4. Open the completed run and download the `FatehMessenger-debug-apk` artifact.

## To make it real
Connect a backend such as Firebase. Create an Android app in Firebase with package name `com.fateh.messenger`, add `google-services.json`, enable a secure sign-in method that does not require phone numbers, configure Firestore rules and Storage rules, then implement server-issued unique user codes, realtime messages, media upload, offline persistence and account security. Never allow public read/write database rules. The current code deliberately does not pretend these backend features are already working.

## Planned feature checklist
- [x] Arabic dark navy/cyan starter UI
- [x] Developer credit: محمد الفاتح
- [x] GitHub Actions APK build workflow
- [x] Navigation and sample chat UI
- [ ] Real accounts and unique server-issued codes
- [ ] Realtime messaging between devices
- [ ] Camera/gallery image upload and audio recording/playback
- [ ] Persistent archive and offline queue/sync
- [ ] Secure optional app lock and privacy implementation
\n\n## غلاف التطبيق\nتمت إضافة صورة الغلاف إلى `app/src/main/res/drawable-nodpi/fateh_cover.jpg` وتظهر على شاشة البداية.\n\n**تنبيه:** هذه نسخة معاينة للواجهة. الحسابات والمراسلة عبر الإنترنت وإرسال الوسائط بين مستخدمين غير مكتملة حتى يتم ربط خدمة خلفية واختبارها.\n